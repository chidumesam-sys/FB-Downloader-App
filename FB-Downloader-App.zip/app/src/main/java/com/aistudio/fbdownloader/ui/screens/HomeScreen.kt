
package com.aistudio.fbdownloader.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aistudio.fbdownloader.downloader.*
import kotlinx.coroutines.launch

@Composable
fun HomeScreen() {

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var url by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp)) {

        Text("FB Downloader")

        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            label = { Text("Facebook URL") }
        )

        Spacer(Modifier.height(10.dp))

        Button(onClick = {
            scope.launch {
                val video = FacebookExtractor.extractVideo(url)
                result = video?.videoUrl ?: "Failed"
            }
        }) { Text("Fetch") }

        Spacer(Modifier.height(10.dp))

        Text(result)

        Spacer(Modifier.height(10.dp))

        Button(onClick = {
            scope.launch {
                val video = FacebookExtractor.extractVideo(url)
                if (video != null) {
                    DownloadHelper.downloadVideo(context, video)
                }
            }
        }) { Text("Download") }
    }
}
