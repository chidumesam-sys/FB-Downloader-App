
package com.aistudio.fbdownloader.downloader

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

object FacebookExtractor {

    private val client = OkHttpClient()

    suspend fun extractVideo(url: String): VideoModel? {
        return withContext(Dispatchers.IO) {
            try {
                val res = client.newCall(Request.Builder().url(url).build()).execute()
                val html = res.body?.string() ?: return@withContext null

                val regex = "hd_src:\"(.*?)\"".toRegex()
                val match = regex.find(html)

                match?.groupValues?.get(1)?.let {
                    VideoModel("Video", it, "HD")
                }
            } catch (e: Exception) {
                null
            }
        }
    }
}
