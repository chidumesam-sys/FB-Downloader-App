
package com.aistudio.fbdownloader.downloader

data class VideoModel(
    val title: String,
    val videoUrl: String,
    val quality: String
)
